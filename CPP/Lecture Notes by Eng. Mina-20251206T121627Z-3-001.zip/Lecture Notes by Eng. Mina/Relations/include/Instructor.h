#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

#include "Marker.h"

class Instructor
{
    public:
        Instructor( ) {}
        //Assocation
        void drawOnBoard(Marker m){

        }
        ~Instructor() {}

    protected:

    private:
};

#endif // INSTRUCTOR_H
