#ifndef MARKER_H
#define MARKER_H


class Marker
{
    public:
        Marker() {}
        ~Marker() {}

    protected:

    private:
};

#endif // MARKER_H
