interface TypeCCharger {
    void chargeWithTypeC();
}