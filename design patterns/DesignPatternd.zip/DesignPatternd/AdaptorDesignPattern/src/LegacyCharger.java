interface LegacyCharger {
    void chargeWithMicroUSB();
}